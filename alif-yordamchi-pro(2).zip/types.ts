
export interface Message {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  image?: string;
  audio?: Uint8Array;
  timestamp: Date;
  sources?: Array<{ web: { uri: string; title: string } }>;
  isSpeaking?: boolean;
}

export interface AppState {
  inputText: string;
  loading: boolean;
  messages: Message[];
  error: string | null;
}

// Added missing Nutrition interface required by NutritionChart component
export interface Nutrition {
  protein: number;
  carbs: number;
  fat: number;
}
