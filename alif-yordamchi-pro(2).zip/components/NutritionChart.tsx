
import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import { Nutrition } from '../types';

interface Props {
  nutrition: Nutrition;
}

const NutritionChart: React.FC<Props> = ({ nutrition }) => {
  const data = [
    { name: 'Oqsillar (Protein)', value: nutrition.protein, color: '#10b981' },
    { name: 'Uglevodlar (Carbs)', value: nutrition.carbs, color: '#3b82f6' },
    { name: 'Yog\'lar (Fat)', value: nutrition.fat, color: '#f59e0b' },
  ];

  return (
    <div className="h-64 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            innerRadius={60}
            outerRadius={80}
            paddingAngle={5}
            dataKey="value"
          >
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.color} />
            ))}
          </Pie>
          <Tooltip />
          <Legend />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
};

export default NutritionChart;
