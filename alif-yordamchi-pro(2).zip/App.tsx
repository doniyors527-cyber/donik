
import React, { useState, useRef, useEffect } from 'react';
import { 
  Send, User, Bot, Loader2, Search, ExternalLink, 
  Sparkles, Image as ImageIcon, Volume2, VolumeX, 
  Trash2, MessageSquare, Plus, Zap, Code, PenTool, 
  ChevronRight, Settings, Info, List, X, Command, Flame, Smile, 
  BookOpen, Globe, Brain, Cpu, Smartphone, DollarSign, Rocket,
  LayoutGrid, Compass, Briefcase, Mic, AudioLines, MoreHorizontal,
  ChevronDown, Share2, UserPlus, Pin, ShieldCheck, History, Star,
  Check, Play, ArrowRight, ZapOff, Video, FlaskConical, Map as MapIcon,
  CreditCard, Wallet, Lock, CheckCircle2, LogIn, Mail, Key,
  Phone, Apple, Monitor, UserCircle2, ShieldAlert, Shield, Fingerprint,
  Paperclip, ImagePlus, MicOff, Waves, Camera, CameraOff, SquarePen,
  History as HistoryIcon, SearchCode, Globe2
} from 'lucide-react';
import { askAlifStream, generateImage, generateSpeech } from './services/geminiService';
import { Message } from './types';
import { GoogleGenAI, LiveServerMessage, Modality, Blob } from "@google/genai";

// Base64 Helpers
function encode(bytes: Uint8Array) {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

// Raw PCM Decoding for Live API
async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

const App: React.FC = () => {
  const [inputText, setInputText] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [sessions, setSessions] = useState<{id: string, title: string}[]>([]);
  const [useSearch, setUseSearch] = useState(false);
  
  // Auth State (Unique Cabinet Logic)
  const [currentUser, setCurrentUser] = useState<{email: string; name: string; keyHash: string} | null>(null);
  const [isAccountConnected, setIsAccountConnected] = useState(false);
  const [nameInput, setNameInput] = useState('');
  const [secretKeyInput, setSecretKeyInput] = useState('');
  const [isAuthenticating, setIsAuthenticating] = useState(false);

  // Live Mode State
  const [isLiveMode, setIsLiveMode] = useState(false);
  const [isLiveConnected, setIsLiveConnected] = useState(false);
  const [liveTranscript, setLiveTranscript] = useState<{user: string, ai: string}>({user: '', ai: ''});
  const liveSessionRef = useRef<any>(null);
  const inputAudioCtxRef = useRef<AudioContext | null>(null);
  const outputAudioCtxRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef(0);
  const activeSourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    try {
      const activeSession = localStorage.getItem('alif_pro_session');
      if (activeSession) {
        const user = JSON.parse(activeSession);
        setCurrentUser(user);
        setIsAccountConnected(true);
        const userStorageKey = `alif_data_${user.keyHash}`;
        const hist = localStorage.getItem(userStorageKey);
        if (hist) setSessions(JSON.parse(hist));
      }
    } catch (e) { console.error("Session restore failed", e); }
  }, []);

  useEffect(() => {
    if (isAccountConnected && currentUser) {
      const userStorageKey = `alif_data_${currentUser.keyHash}`;
      localStorage.setItem(userStorageKey, JSON.stringify(sessions));
    }
  }, [sessions, isAccountConnected, currentUser]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const performAuth = async () => {
    if (!nameInput.trim() || !secretKeyInput.trim()) { 
      setError("Ism va Maxfiy kalitni kiriting."); 
      return; 
    }
    setIsAuthenticating(true);
    
    // Simulate hashing/unique storage key
    const keyHash = btoa(`${nameInput.toLowerCase().trim()}:${secretKeyInput}`);
    
    setTimeout(() => {
      const userData = { 
        email: `${nameInput.toLowerCase().trim()}@alif.ai`, 
        name: nameInput,
        keyHash: keyHash 
      };
      localStorage.setItem('alif_pro_session', JSON.stringify(userData));
      setCurrentUser(userData);
      setIsAccountConnected(true);
      setIsAuthenticating(false);
      
      // Load this specific cabinet's history
      const userStorageKey = `alif_data_${keyHash}`;
      const hist = localStorage.getItem(userStorageKey);
      if (hist) setSessions(JSON.parse(hist));
      else setSessions([]);
    }, 1000);
  };

  const startNewChat = () => {
    if (messages.length > 0) {
      const title = messages[0].text.substring(0, 30) + "...";
      setSessions(prev => [{ id: Date.now().toString(), title }, ...prev].slice(0, 20));
    }
    setMessages([]);
    setError(null);
  };

  const stopLiveSession = () => {
    if (liveSessionRef.current?.stopMedia) liveSessionRef.current.stopMedia();
    if (liveSessionRef.current?.sessionPromise) {
      liveSessionRef.current.sessionPromise.then((s: any) => {
        try { s.close(); } catch(e) {}
      });
    }
    activeSourcesRef.current.forEach(s => { try { s.stop(); } catch(e){} });
    activeSourcesRef.current.clear();
    setIsLiveMode(false); 
    setIsLiveConnected(false);
    nextStartTimeRef.current = 0;
  };

  const startLiveSession = async () => {
    if (isLiveMode) return;
    setIsLiveMode(true);
    setLiveTranscript({user: '', ai: ''});
    
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      inputAudioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      outputAudioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      
      await inputAudioCtxRef.current.resume();
      await outputAudioCtxRef.current.resume();

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        callbacks: {
          onopen: () => {
            setIsLiveConnected(true);
            const source = inputAudioCtxRef.current!.createMediaStreamSource(stream);
            const scriptProcessor = inputAudioCtxRef.current!.createScriptProcessor(4096, 1, 1);
            
            scriptProcessor.onaudioprocess = (ev) => {
              const inputData = ev.inputBuffer.getChannelData(0);
              const int16 = new Int16Array(inputData.length);
              for (let i = 0; i < inputData.length; i++) {
                int16[i] = inputData[i] * 32768;
              }
              const pcmBlob: Blob = { 
                data: encode(new Uint8Array(int16.buffer)), 
                mimeType: 'audio/pcm;rate=16000' 
              };
              
              sessionPromise.then(session => {
                session.sendRealtimeInput({ media: pcmBlob });
              }).catch(e => console.error("Send failed", e));
            };
            
            source.connect(scriptProcessor);
            scriptProcessor.connect(inputAudioCtxRef.current!.destination);
            
            (liveSessionRef.current as any) = { 
              stopMedia: () => {
                source.disconnect();
                scriptProcessor.disconnect();
                stream.getTracks().forEach(track => track.stop());
              }
            };
          },
          onmessage: async (message: LiveServerMessage) => {
            if (message.serverContent?.inputTranscription) {
              setLiveTranscript(prev => ({ ...prev, user: message.serverContent.inputTranscription!.text }));
            }
            if (message.serverContent?.outputTranscription) {
              setLiveTranscript(prev => ({ ...prev, ai: prev.ai + message.serverContent!.outputTranscription!.text }));
            }

            const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (base64Audio && outputAudioCtxRef.current) {
              const audioBuffer = await decodeAudioData(
                decode(base64Audio), 
                outputAudioCtxRef.current, 
                24000, 
                1
              );
              
              const source = outputAudioCtxRef.current.createBufferSource();
              source.buffer = audioBuffer;
              source.connect(outputAudioCtxRef.current.destination);
              
              const now = outputAudioCtxRef.current.currentTime;
              const startTime = Math.max(nextStartTimeRef.current, now);
              source.start(startTime);
              nextStartTimeRef.current = startTime + audioBuffer.duration;
              
              activeSourcesRef.current.add(source);
              source.onended = () => activeSourcesRef.current.delete(source);
            }

            if (message.serverContent?.interrupted) {
              activeSourcesRef.current.forEach(s => { try { s.stop(); } catch(e){} });
              activeSourcesRef.current.clear();
              nextStartTimeRef.current = 0;
            }
            
            if (message.serverContent?.turnComplete) {
              setTimeout(() => {
                setLiveTranscript({user: '', ai: ''});
              }, 3000);
            }
          },
          onerror: (e) => {
            console.error("Live Error", e);
            setError("Ulanishda xatolik yuz berdi.");
            stopLiveSession();
          },
          onclose: () => {
            stopLiveSession();
          }
        },
        config: {
          responseModalities: [Modality.AUDIO],
          inputAudioTranscription: {},
          outputAudioTranscription: {},
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } }
          },
          systemInstruction: "Siz Alif Super AI yordamchisiz. Ovozli muloqot orqali tezkor va aqlli yordam bering. Har doim o'zbek tilida javob bering.",
        }
      });
      liveSessionRef.current = { ...(liveSessionRef.current || {}), sessionPromise };
    } catch (e) { 
      setIsLiveMode(false); 
      setError("Mikrofon yoki ulanishda muammo: " + (e as Error).message); 
    }
  };

  const handleSend = async (e?: React.FormEvent, customText?: string) => {
    if (e) e.preventDefault();
    const textToSend = customText || inputText;
    if (!textToSend.trim() || loading) return;
    
    const userMsg: Message = { 
      id: Math.random().toString(36).substr(2, 9), 
      role: 'user', 
      text: textToSend,
      timestamp: new Date() 
    };
    
    setMessages(prev => [...prev, userMsg]);
    setInputText('');
    setLoading(true);

    try {
      const history = messages.slice(-10).map(m => ({
        role: m.role === 'user' ? 'user' as const : 'model' as const,
        parts: [{ text: m.text }]
      }));
      
      const responseStream = await askAlifStream(userMsg.text, history, useSearch);
      const assistantId = Math.random().toString(36).substr(2, 9);
      setMessages(prev => [...prev, { id: assistantId, role: 'assistant', text: "", timestamp: new Date() }]);
      
      let fullText = "";
      for await (const chunk of responseStream) {
        fullText += (chunk as any).text || "";
        setMessages(prev => prev.map(m => m.id === assistantId ? { 
          ...m, 
          text: fullText, 
          sources: (chunk as any).candidates?.[0]?.groundingMetadata?.groundingChunks 
        } : m));
      }
    } catch (err) { 
      setError("Xabarni yuborishda xatolik."); 
    } finally { 
      setLoading(false); 
    }
  };

  return (
    <div className="flex h-screen bg-[#050506] text-[#f1f5f9] font-sans overflow-hidden">
      {/* Sidebar */}
      <aside className="w-72 hidden lg:flex flex-col border-r border-white/5 bg-[#08080a] px-4 py-8 relative z-50">
        <div className="flex items-center gap-3 mb-10 px-2">
          <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center shadow-[0_0_20px_rgba(37,99,235,0.4)]">
            <Zap size={22} className="text-white fill-white" />
          </div>
          <div>
            <h1 className="text-lg font-black tracking-tight leading-none">ALIF PRO</h1>
            <span className="text-[10px] text-blue-500 font-bold tracking-widest uppercase">Super AI System</span>
          </div>
        </div>

        <button onClick={startNewChat} className="w-full h-12 flex items-center gap-3 px-4 rounded-xl bg-white/5 hover:bg-white/10 transition-all mb-8 border border-white/5 group">
          <SquarePen size={18} className="text-blue-500 group-hover:scale-110 transition-transform" />
          <span className="text-sm font-bold">Yangi chat</span>
        </button>

        <div className="flex-1 overflow-y-auto space-y-2 scrollbar-hide">
          <p className="text-[10px] font-black text-slate-600 uppercase tracking-[0.2em] mb-4 px-2">Mening Kabinetim</p>
          {sessions.length > 0 ? sessions.map(s => (
            <button key={s.id} className="w-full text-left px-3 py-3 rounded-xl hover:bg-white/[0.03] text-sm text-slate-400 truncate border border-transparent hover:border-white/5 transition-all">
               {s.title}
            </button>
          )) : <p className="text-[11px] text-slate-700 italic px-2">Tarix bo'sh</p>}
        </div>

        <div className="mt-6 pt-6 border-t border-white/5">
           <div className="flex items-center gap-3 p-3 rounded-2xl bg-white/[0.02] border border-white/5">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center font-black text-sm uppercase shadow-xl">
                {currentUser?.name.charAt(0)}
              </div>
              <div className="flex-1 min-w-0">
                 <p className="text-sm font-bold truncate">{currentUser?.name}</p>
                 <button onClick={() => { localStorage.removeItem('alif_pro_session'); setIsAccountConnected(false); }} className="text-[10px] text-red-500 hover:text-red-400 font-bold uppercase tracking-tighter transition-colors">Tizimdan chiqish</button>
              </div>
           </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col relative bg-[#050506]">
        <header className="h-20 flex items-center justify-between px-8 bg-[#050506]/60 backdrop-blur-3xl border-b border-white/5 z-40">
           <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 bg-blue-500/10 px-3 py-1.5 rounded-full border border-blue-500/20">
                <div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse"></div>
                <span className="text-[11px] font-bold text-blue-400 tracking-wider">TIZIM FAOL</span>
              </div>
           </div>
           <div className="flex items-center gap-3">
              {/* Search Toggle moved to Header */}
              <button 
                onClick={() => setUseSearch(!useSearch)} 
                className={`h-11 flex items-center gap-2 px-4 rounded-2xl font-black text-[10px] tracking-widest uppercase transition-all ${useSearch ? 'bg-blue-600 text-white shadow-[0_0_20px_rgba(37,99,235,0.3)]' : 'bg-white/5 text-slate-400 border border-white/5 hover:bg-white/10'}`}
              >
                 <Search size={16} />
                 <span className="hidden sm:inline">QIDIRUV: {useSearch ? "YOQILGAN" : "O'CHIK"}</span>
              </button>

              <button 
                onClick={() => isLiveMode ? stopLiveSession() : startLiveSession()}
                className={`h-11 flex items-center gap-3 px-6 rounded-2xl font-black text-xs uppercase tracking-widest transition-all ${isLiveMode ? 'bg-red-600 text-white shadow-2xl animate-pulse' : 'bg-white/5 text-slate-300 hover:bg-white/10 border border-white/5'}`}
              >
                 {isLiveMode ? <Waves size={16} /> : <Mic size={16} />}
                 {isLiveMode ? "LIVE" : "OVOZLI"}
              </button>
           </div>
        </header>

        {/* Chat Area */}
        <div className="flex-1 overflow-y-auto px-8 pb-40 relative">
          <div className="max-w-4xl mx-auto py-12">
            {isLiveMode ? (
              <div className="h-[60vh] flex flex-col items-center justify-center text-center">
                <div className="relative mb-12">
                  <div className="w-48 h-48 rounded-full border-2 border-blue-500/20 flex items-center justify-center animate-spin-slow">
                    <div className="w-40 h-40 rounded-full border-2 border-blue-500/40 flex items-center justify-center animate-reverse">
                      <div className="w-32 h-32 rounded-full bg-blue-600 flex items-center justify-center shadow-[0_0_60px_rgba(37,99,235,0.4)]">
                        <Waves size={54} className="text-white animate-pulse" />
                      </div>
                    </div>
                  </div>
                </div>
                <h2 className="text-4xl font-black tracking-tighter mb-4">{isLiveConnected ? "Sizni eshityapman..." : "Ulanmoqdaman..."}</h2>
                <div className="space-y-6 max-w-2xl px-4 min-h-[100px]">
                   {liveTranscript.user && <p className="text-slate-500 text-lg font-medium italic">"{liveTranscript.user}"</p>}
                   {liveTranscript.ai && <p className="text-blue-400 text-2xl font-bold leading-relaxed">{liveTranscript.ai}</p>}
                </div>
              </div>
            ) : messages.length === 0 ? (
              <div className="h-[70vh] flex flex-col items-center justify-center text-center">
                 <div className="w-24 h-24 bg-white/5 rounded-[2.5rem] flex items-center justify-center mb-10 border border-white/10 transform rotate-12">
                    <Sparkles size={44} className="text-blue-500" />
                 </div>
                 <h1 className="text-6xl md:text-8xl font-black tracking-tighter mb-6 bg-clip-text text-transparent bg-gradient-to-b from-white to-white/40">
                   Salom, <span className="text-blue-600">{currentUser?.name}</span>
                 </h1>
                 <p className="text-xl md:text-2xl font-medium text-slate-500 mb-16 max-w-2xl">Bu sizning shaxsiy va xavfsiz Alif Pro kabinetingiz. Xush kelibsiz!</p>
                 
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full max-w-2xl">
                    <SuggestionBox icon={Zap} title="Tezkor Bilim" desc="Eng so'nggi texnologiyalar haqida" onClick={() => handleSend(undefined, "AI sohasidagi eng oxirgi yangiliklar")} />
                    <SuggestionBox icon={Code} title="Dasturlash" desc="Skriptlar va algoritmlar" onClick={() => handleSend(undefined, "React-da chiroyli login komponenti kodi")} />
                 </div>
              </div>
            ) : (
              <div className="space-y-12">
                {messages.map(m => (
                  <div key={m.id} className={`flex gap-6 animate-in slide-in-from-bottom-4 ${m.role === 'user' ? 'justify-end' : ''}`}>
                    {m.role === 'assistant' && (
                      <div className="w-10 h-10 rounded-xl bg-white flex-shrink-0 flex items-center justify-center shadow-xl">
                        <Zap size={20} className="text-black fill-black" />
                      </div>
                    )}
                    <div className={`max-w-3xl min-w-0 ${m.role === 'user' ? 'text-right' : ''}`}>
                       <div className={`message-content text-lg leading-relaxed ${m.role === 'user' ? 'text-blue-400 font-bold' : 'text-slate-200'} whitespace-pre-wrap`}>
                         {m.text || <Loader2 className="animate-spin text-blue-500" size={24} />}
                       </div>
                       {m.sources && (
                         <div className="mt-4 flex flex-wrap gap-2">
                           {m.sources.map((s: any, idx) => (
                             <a key={idx} href={s.web?.uri} target="_blank" className="flex items-center gap-2 px-3 py-1 bg-white/5 hover:bg-white/10 border border-white/10 rounded-full text-[10px] font-bold text-blue-400 transition-all">
                               <Globe size={10} /> {s.web?.title || 'Manba'}
                             </a>
                           ))}
                         </div>
                       )}
                    </div>
                    {m.role === 'user' && (
                      <div className="w-10 h-10 rounded-xl bg-blue-600 flex-shrink-0 flex items-center justify-center font-black shadow-xl">
                        {currentUser?.name.charAt(0)}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
            <div ref={messagesEndRef} className="h-40" />
          </div>
        </div>

        {/* Input Area */}
        {!isLiveMode && (
          <div className="absolute bottom-0 left-0 right-0 p-8 z-50">
            <div className="max-w-4xl mx-auto">
              <div className="bg-[#121214]/90 backdrop-blur-3xl border border-white/10 rounded-[2.5rem] p-4 shadow-2xl">
                <textarea 
                  rows={1}
                  placeholder="Xabaringizni yozing..."
                  value={inputText}
                  onChange={e => setInputText(e.target.value)}
                  onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); } }}
                  className="w-full bg-transparent border-none focus:ring-0 text-xl py-4 px-6 text-white placeholder:text-slate-700 resize-none font-medium"
                />
                <div className="flex items-center justify-end px-4 pt-4 border-t border-white/5">
                   <button 
                     onClick={() => handleSend()}
                     disabled={!inputText.trim() || loading}
                     className={`h-12 px-8 rounded-2xl font-black text-sm tracking-widest uppercase flex items-center gap-3 transition-all ${inputText.trim() ? 'bg-white text-black hover:scale-105' : 'bg-white/5 text-slate-800'}`}
                   >
                     {loading ? <Loader2 className="animate-spin" /> : <>YUBORISH <Send size={16} /></>}
                   </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Unique Cabinet Auth Screen */}
      {!isAccountConnected && (
        <div className="fixed inset-0 z-[100] bg-[#050506] flex items-center justify-center p-8">
           <div className="w-full max-w-md space-y-12">
              <div className="text-center space-y-4">
                <div className="w-20 h-20 bg-blue-600 rounded-3xl flex items-center justify-center mx-auto shadow-2xl">
                  <Zap size={40} className="text-white fill-white" />
                </div>
                <h1 className="text-5xl font-black tracking-tighter">ALIF <span className="text-blue-600">PRO</span></h1>
                <p className="text-slate-600 font-bold uppercase tracking-[0.2em] text-[10px]">Shaxsiy Kabinet Tizimi</p>
              </div>

              <div className="bg-white/[0.02] border border-white/10 p-10 rounded-[2.5rem] shadow-2xl space-y-6">
                 <div className="space-y-4">
                   <div className="space-y-2">
                     <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Foydalanuvchi ismi</label>
                     <div className="relative">
                        <UserCircle2 className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-600" size={20} />
                        <input 
                          type="text"
                          placeholder="Masalan: Ali"
                          value={nameInput}
                          onChange={e => setNameInput(e.target.value)}
                          className="w-full h-16 bg-white/5 border border-white/10 rounded-2xl pl-14 pr-6 text-lg font-bold outline-none focus:border-blue-500/50"
                        />
                     </div>
                   </div>

                   <div className="space-y-2">
                     <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Maxfiy Kalit</label>
                     <div className="relative">
                        <Key className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-600" size={20} />
                        <input 
                          type="password"
                          placeholder="O'zingizga xos maxfiy so'z"
                          value={secretKeyInput}
                          onChange={e => setSecretKeyInput(e.target.value)}
                          className="w-full h-16 bg-white/5 border border-white/10 rounded-2xl pl-14 pr-6 text-lg font-bold outline-none focus:border-blue-500/50"
                        />
                     </div>
                   </div>
                 </div>

                 <button 
                   onClick={performAuth}
                   disabled={isAuthenticating}
                   className="w-full h-16 bg-white text-black rounded-2xl font-black text-lg hover:bg-blue-600 hover:text-white transition-all flex items-center justify-center gap-3"
                 >
                   {isAuthenticating ? <Loader2 className="animate-spin" /> : "Kabinetga kirish"}
                 </button>
                 
                 <p className="text-[10px] text-slate-700 text-center font-medium leading-relaxed">
                   Eslatma: Har doim bir xil ism va kalitdan foydalaning.
                 </p>
              </div>
           </div>
        </div>
      )}

      {error && (
        <div className="fixed bottom-10 left-1/2 -translate-x-1/2 z-[200]">
           <div className="bg-red-600 text-white px-8 py-4 rounded-2xl shadow-2xl flex items-center gap-4">
             <ShieldAlert size={20} />
             <span className="font-bold text-sm">{error}</span>
             <button onClick={() => setError(null)} className="ml-4 p-1 hover:bg-white/10 rounded-full"><X size={16} /></button>
           </div>
        </div>
      )}
    </div>
  );
};

const SuggestionBox = ({ icon: Icon, title, desc, onClick }: any) => (
  <button onClick={onClick} className="p-8 bg-white/[0.02] border border-white/5 rounded-[2rem] hover:bg-white/5 hover:border-blue-500/30 transition-all text-left group">
    <Icon size={32} className="text-blue-600 mb-4 group-hover:scale-110 transition-transform" />
    <h3 className="font-black text-lg mb-1">{title}</h3>
    <p className="text-slate-600 text-sm">{desc}</p>
  </button>
);

export default App;
